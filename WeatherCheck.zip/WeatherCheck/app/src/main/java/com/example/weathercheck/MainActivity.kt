package com.example.weathercheck

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.weathercheck.databinding.ActivityMainBinding
import com.squareup.picasso.Picasso
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityMainBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        binding.mainButton.setOnClickListener {
            if(binding.userField.text.toString().trim().equals(""))
                Toast.makeText(this, "ENTER YOUR CITY!!!", Toast.LENGTH_LONG).show()
            else {
                var city: String = binding.userField.text.toString()
                var key: String = "a75c089527f0349d6d5ab9251a9d633f"
                var url: String = "https://api.openweathermap.org/data/2.5/weather?q=$city&appid=$key&units=metric&lang=ru"
                GlobalScope.launch(Dispatchers.IO) {
                    val apiResponce = URL(url).readText()
                    val weather = JSONObject(apiResponce).getJSONArray("weather")
                    val desc = weather.getJSONObject(0).getString("description")
                    val iconId = weather.getJSONObject(0).getString("icon")
                    val main = JSONObject(apiResponce).getJSONObject("main")
                    val temp = main.getString("temp")
                    val humidity = main.getString("humidity")
                    val imgURL = "https://api.openweathermap.org/img/w/$iconId.png"

                    withContext(Dispatchers.Main) {
                        binding.resultInfo.text = "Температура: $temp c\nВлажность: $humidity %\n$desc"
                        Picasso.get().load(imgURL).resize(1000,1000).into(binding.imageWeather)

                    }
                }
            }
        }
    }
}